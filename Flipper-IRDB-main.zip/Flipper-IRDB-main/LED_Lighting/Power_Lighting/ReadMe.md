# Power Lighting Meteor VI

## Scanned & tested by Foul (2022)

![Face](https://user-images.githubusercontent.com/57457139/183279904-0f303ae6-c2dd-4a30-adbc-96f0d46a60da.jpg)
![Back](https://user-images.githubusercontent.com/57457139/183279906-4a3a9af9-1c9b-4786-9656-b75fd7bf3f3d.jpg)
![Remote](https://user-images.githubusercontent.com/57457139/183279927-116beeaf-af40-4ee7-991a-6d36f1bce5f4.jpg
